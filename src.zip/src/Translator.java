import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

/*
 * Translator class
 * Class for taking various input and assigning meaning and effects to them, distributing them
 * to appropriate methods based on constructed meaning.
 */
public class Translator {
	Properties properties = new Properties();
	static String libraryRoot = "data/" + Main.getUniverse().toLowerCase();
	public boolean translationInit() throws IOException{
		for(int x = 0; x < Input.commandsUsed.size(); x++){
			String type = fetchType("command", Input.commandsUsed.get(x));
			try {
				if(!type.equals(null)){
					switch(type){
						case "search":{
							String output = searchOutput();
							try {
								if(!output.equals(null)){
									System.out.print(output);
									return true;
								}
							} catch (NullPointerException searchOutputNPE) {
								return false;
							}
							break;
						}
						default:{
							return false;
						}
					}
				}
			} catch (NullPointerException translationNPE) {
			}
		}
		return false;
	}
	public String fetchType(String subDirectory, String toFind) throws IOException{
		File[] directory = new File(libraryRoot + "/" + subDirectory).listFiles();
		for(int x = 0; x < directory.length; x++){
			if(directory[x].getName().equalsIgnoreCase(toFind + ".txt")){
				return properties.propertiesInit(directory[x].getPath(), "type", 0);
			}
		}
		return null;
	}
	public String searchOutput(){
		String output = null;
		for(int x = 0; x < Main.localeInventory.length; x++){
			for(int y = 0; y < Main.localeInventory[x].length; y++){
				
			}
		}
		return output;
	}
}

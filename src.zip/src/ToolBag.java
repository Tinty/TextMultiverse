import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
/*
 * ToolBag Class
 * This class contains supporting methods providing and fulfilling various functionality requirements for the engine.
 */
public class ToolBag {
	public int fileLines(String fileDirectory, String exclusion) throws IOException{
		BufferedReader fileReader = null;
		try {
			fileReader = new BufferedReader(
					new InputStreamReader(getClass().getResourceAsStream(fileDirectory)));
		} catch (NullPointerException propertiesReaderNPE) {
			try {
				fileReader = new BufferedReader(
						new InputStreamReader(new FileInputStream(fileDirectory)));
			} catch (NullPointerException propertiesReaderNPE2) {
				System.err.print("\nThe directory: " + fileDirectory + " failed to load.\n\n");
				propertiesReaderNPE2.printStackTrace();
			}
		}
		String readIn = null;
		int lineCount = 0;
		do{
			try {
				readIn = fileReader.readLine();
				if(readIn.startsWith(exclusion)
						&& !exclusion.equals("")){
					continue;
				}
				lineCount++;
			} catch (NullPointerException fileReaderCounterNPE) {
				break;
			}
			
		}while(!readIn.equals(null));
		return lineCount;
	}
}
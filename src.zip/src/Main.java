import java.io.File;
import java.io.IOException;
/*
 * Pnoy
 * 
 * Main Class
 * From here methods and classes will be called to perform required actions
 * for the engine on demand.
 */
public class Main {
	public static String universe = null;
	public static boolean systemReady = false;
	public static String[][][] localeInventory;
	public static void main(String[] args) throws IOException, InterruptedException{
		Window window = new Window();
		DatabaseManagement database = new DatabaseManagement();
		User user = new User();
		window.windowInit();
		database.databaseInit();
		database.listsInit();
		if(!user.userInit()){
			//error & terminate output start
			System.err.print("The user was not found.\n");
			Thread.sleep(3000);
			System.out.print("\nTerminating...\n");
			Thread.sleep(10000);
			System.exit(001);
			//error & terminate output end
		}else{
			loadLocale();
			systemReady = true;
		}
	}
	public static void setUniverse(String incoming){
		universe = incoming;
	}
	public static String getUniverse(){
		return universe;
	}
	public static void loadLocale() throws IOException{
		Properties properties = new Properties();
		File[] directory = new File(User.userLocation).listFiles();
		localeInventory = new String[directory.length][][];
		if(Input.localesUsed.isEmpty()
				&& Input.charactersUsed.isEmpty()
				&& Input.objectsUsed.isEmpty()
				&& Input.othersUsed.isEmpty()){
			for(int x = 0; x < directory.length; x++){
				File[] subDirectory = new File(directory[x].getPath()).listFiles();
				for(int y = 0; y < subDirectory.length; y++){
					if(subDirectory[y].isFile()
							&& subDirectory[y].getName().endsWith(".txt")){
						localeInventory[x] = properties.fileReadIn(subDirectory[y].getPath());
					}
				}
			}
		}
	}
}
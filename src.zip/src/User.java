/*
 * User class
 * Class specifically for accessing and calling methods that refer to the user end of the software.
 */
public class User {
	DatabaseManagement database = new DatabaseManagement();
	public static String userLocation = null;
	//return true if user is found, false if not.
	public boolean userInit(){
		//Scan database for c_user start
		for(int x = 0; x < database.universeDirectory.length; x++){
			if(database.universeDirectory[x][2].contains("c_user")){
				userLocation = database.universeDirectory[x][0];
				return true;
			}
		}
		return false;
		//Scan database for c_user end
	}
}